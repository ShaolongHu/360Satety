package com.anjoyo.anjoyosafety.activity;

import android.os.Handler;

import com.anjoyo.anjoyosafety.base.MyBaseActivity;
import com.anjoyo.anjoyosatety.activity.R;

public class PersonalSpaceSettingPwdActivity extends MyBaseActivity {
	public static Handler handler;
	@Override
	protected void controll() {
		// TODO Auto-generated method stub

	}

	@Override
	protected void findViewById() {
		// TODO Auto-generated method stub

	}

	@Override
	protected void setContentView() {
		// TODO Auto-generated method stub
setContentView(R.layout.passwrod);
	}

}
