package com.anjoyo.anjoyosafety.activity;

import com.anjoyo.anjoyosafety.base.MyBaseActivity;
import com.anjoyo.anjoyosatety.activity.R;

public class Tag_SubCrankAd extends MyBaseActivity{

	@Override
	protected void setContentView() {
		// TODO Auto-generated method stub
		setContentView(R.layout.tag_subcrank);
	}

	@Override
	protected void findViewById() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void controll() {
		// TODO Auto-generated method stub
		
	}

}
