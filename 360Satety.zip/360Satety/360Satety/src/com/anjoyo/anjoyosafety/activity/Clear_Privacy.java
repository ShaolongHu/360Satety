package com.anjoyo.anjoyosafety.activity;

import com.anjoyo.anjoyosafety.base.MyBaseActivity;
import com.anjoyo.anjoyosatety.activity.R;

public class Clear_Privacy extends MyBaseActivity{

	@Override
	protected void controll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void findViewById() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void setContentView() {
		setContentView(R.layout.clear_privacy);
		
	}

}
