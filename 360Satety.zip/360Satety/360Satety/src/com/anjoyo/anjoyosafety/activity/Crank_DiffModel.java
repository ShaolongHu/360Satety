package com.anjoyo.anjoyosafety.activity;

import com.anjoyo.anjoyosatety.activity.R;

import android.app.Activity;
import android.os.Bundle;

public class Crank_DiffModel extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.crank_diffmodel);
		
	}
}
