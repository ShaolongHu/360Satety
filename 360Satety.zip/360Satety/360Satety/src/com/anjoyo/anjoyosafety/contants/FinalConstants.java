package com.anjoyo.anjoyosafety.contants;

public class FinalConstants {
	public static final String PERSON_SPACE_PWD = "password";
	public static final String PERSON_SPACE_FILE_PWD = "personSpacePassword";
}
