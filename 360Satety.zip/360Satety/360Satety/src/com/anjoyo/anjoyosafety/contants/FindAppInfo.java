package com.anjoyo.anjoyosafety.contants;

import android.graphics.drawable.Drawable;

public class FindAppInfo {
	
	public Drawable appIcon=null;
	public Drawable getAppIcon() {
		return appIcon;
	}
	public void setAppIcon(Drawable appIcon) {
		this.appIcon = appIcon;
	}
}
