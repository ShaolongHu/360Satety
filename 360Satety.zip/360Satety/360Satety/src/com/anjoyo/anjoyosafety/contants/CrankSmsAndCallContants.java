package com.anjoyo.anjoyosafety.contants;

public class CrankSmsAndCallContants {

	public static int FLAGSMS = 1;
	
	
}
